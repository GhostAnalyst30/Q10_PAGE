import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { processPayment } from "../services/payment";
import { TRPCError } from "@trpc/server";

export const paymentsRouter = router({
  // Process a demo payment
  processPayment: protectedProcedure
    .input(
      z.object({
        courseId: z.number(),
        amount: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user?.email || !ctx.user?.name) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "User information incomplete",
        });
      }

      try {
        const result = await processPayment({
          userId: ctx.user.id,
          courseId: input.courseId,
          userEmail: ctx.user.email,
          userName: ctx.user.name,
          amount: input.amount,
        });

        if (!result.success) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: result.message,
          });
        }

        return {
          success: true,
          orderId: result.orderId,
          transactionId: result.transactionId,
          message: result.message,
        };
      } catch (error) {
        console.error("[Payments] Error processing payment:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Error al procesar el pago",
        });
      }
    }),

  // Get payment confirmation status
  getConfirmation: protectedProcedure
    .input(
      z.object({
        orderId: z.number(),
      })
    )
    .query(async ({ input, ctx }) => {
      // In a real implementation, this would fetch from database
      return {
        orderId: input.orderId,
        status: "confirmed",
        message: "Tu pago ha sido confirmado exitosamente",
      };
    }),
});
