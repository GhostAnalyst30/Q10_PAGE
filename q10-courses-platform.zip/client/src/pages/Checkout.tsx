import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Lock, CheckCircle, AlertCircle } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Checkout() {
  const [, navigate] = useLocation();
  const [route, params] = useRoute("/checkout/:courseId");
  const { user, isAuthenticated } = useAuth();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [orderId, setOrderId] = useState<number | null>(null);
  const [transactionId, setTransactionId] = useState<string | null>(null);

  const courseId = parseInt(params?.courseId || "1");
  const courseQuery = trpc.courses.getById.useQuery({ id: courseId });
  const paymentMutation = trpc.payments.processPayment.useMutation();

  const course = courseQuery.data;

  useEffect(() => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/checkout/" + params?.courseId);
    }
  }, [isAuthenticated, params?.courseId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      const result = await paymentMutation.mutateAsync({
        courseId: courseId,
        amount: course?.price || "0.00",
      });

      if (result.success) {
        setOrderId(result.orderId || null);
        setTransactionId(result.transactionId || null);
        setPaymentSuccess(true);
        toast.success("¡Pago confirmado exitosamente!");

        // Redirect to profile after 3 seconds
        setTimeout(() => {
          navigate("/profile");
        }, 3000);
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast.error("Error al procesar el pago. Por favor, intenta de nuevo.");
      setIsProcessing(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">
            Redirigiendo a autenticación...
          </p>
        </div>
      </div>
    );
  }

  if (courseQuery.isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">Cargando información del curso...</p>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Curso no encontrado</p>
          <Button onClick={() => navigate("/courses")}>Volver a Cursos</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => navigate("/")}
            className="text-2xl font-bold tracking-tight hover:opacity-75 transition-opacity"
          >
            <span className="text-primary">Q10</span> Academy
          </button>
          <Button
            variant="ghost"
            onClick={() => navigate("/courses")}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver
          </Button>
        </div>
      </nav>

      <main className="py-12">
        <div className="container max-w-4xl">
          <h1 className="text-4xl font-bold mb-12">Completar Compra</h1>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Checkout Form */}
            <div className="md:col-span-2">
              {paymentSuccess ? (
                <div className="bg-card border border-border rounded-sm p-8 space-y-6">
                  <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-8 h-8 text-green-600" />
                    </div>
                  </div>

                  <div className="text-center space-y-4">
                    <h2 className="text-2xl font-bold">¡Pago Confirmado!</h2>
                    <p className="text-muted-foreground">
                      Tu compra ha sido procesada exitosamente. Recibirás un email de confirmación en breve.
                    </p>

                    <div className="bg-secondary/30 rounded-sm p-4 space-y-2 text-left">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ID de Orden:</span>
                        <span className="font-mono font-semibold">#{orderId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ID de Transacción:</span>
                        <span className="font-mono text-xs font-semibold break-all">
                          {transactionId}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Monto:</span>
                        <span className="font-semibold">${course.price}</span>
                      </div>
                    </div>

                    <div className="pt-4 space-y-3">
                      <p className="text-sm text-muted-foreground">
                        Redirigiendo a tu perfil en 3 segundos...
                      </p>
                      <Button
                        onClick={() => navigate("/profile")}
                        className="w-full"
                      >
                        Ir a Mi Perfil
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Personal Info */}
                  <div className="bg-card border border-border rounded-sm p-6 space-y-4">
                    <h2 className="text-xl font-bold">Información Personal</h2>
                    <div className="space-y-3">
                      <Input
                        placeholder="Nombre completo"
                        value={user?.name || ""}
                        disabled
                        className="bg-muted"
                      />
                      <Input
                        placeholder="Email"
                        type="email"
                        value={user?.email || ""}
                        disabled
                        className="bg-muted"
                      />
                    </div>
                  </div>

                  {/* Payment Info */}
                  <div className="bg-card border border-border rounded-sm p-6 space-y-4">
                    <h2 className="text-xl font-bold flex items-center gap-2">
                      <Lock className="w-5 h-5 text-primary" />
                      Información de Pago (Demo)
                    </h2>

                    <div className="bg-blue-50 border border-blue-200 rounded-sm p-4 text-sm text-blue-900">
                      <div className="flex gap-2">
                        <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold mb-1">Modo Demo</p>
                          <p>
                            Usa la tarjeta de prueba: <strong>4242 4242 4242 4242</strong>
                          </p>
                          <p className="text-xs mt-1">
                            Fecha: cualquier fecha futura | CVV: cualquier número
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Input
                        placeholder="Nombre en la tarjeta"
                        defaultValue="Demo Card"
                        disabled
                        className="bg-muted"
                      />

                      <Input
                        placeholder="4242 4242 4242 4242"
                        defaultValue="4242 4242 4242 4242"
                        disabled
                        className="bg-muted"
                      />

                      <div className="grid grid-cols-2 gap-3">
                        <Input
                          placeholder="MM/YY"
                          defaultValue="12/25"
                          disabled
                          className="bg-muted"
                        />
                        <Input
                          placeholder="CVV"
                          defaultValue="123"
                          disabled
                          className="bg-muted"
                        />
                      </div>
                    </div>

                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Tu información de pago está protegida
                    </p>
                  </div>

                  {/* Terms */}
                  <div className="bg-secondary/30 border border-border rounded-sm p-4">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="mt-1" />
                      <span className="text-sm text-muted-foreground">
                        Acepto los términos de servicio y la política de privacidad
                      </span>
                    </label>
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full"
                    disabled={isProcessing}
                  >
                    {isProcessing ? "Procesando..." : "Completar Compra"}
                  </Button>
                </form>
              )}
            </div>

            {/* Order Summary */}
            <div className="sticky top-24 h-fit">
              <div className="bg-card border border-border rounded-sm p-6 space-y-4">
                <h2 className="text-xl font-bold">Resumen del Pedido</h2>

                <div className="space-y-3 pb-4 border-b border-border">
                  <div>
                    <p className="font-semibold">{course.title}</p>
                    <p className="text-sm text-muted-foreground">
                      Acceso de por vida
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>${course.price}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Impuestos</span>
                    <span>$0.00</span>
                  </div>
                </div>

                <div className="border-t border-border pt-4 flex justify-between items-center">
                  <span className="font-bold">Total</span>
                  <span className="text-2xl font-bold text-primary">
                    ${course.price}
                  </span>
                </div>

                <div className="bg-secondary/30 rounded-sm p-3 text-xs text-muted-foreground space-y-2">
                  <p>✓ Acceso inmediato</p>
                  <p>✓ Certificado incluido</p>
                  <p>✓ Garantía de 30 días</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
