# Guía de Configuración y Despliegue - Q10 Academy

## 📋 Índice
1. [Configuración Inicial](#configuración-inicial)
2. [Base de Datos](#base-de-datos)
3. [Dominio Personalizado](#dominio-personalizado)
4. [Pagos con Stripe](#pagos-con-stripe)
5. [Notificaciones por Email](#notificaciones-por-email)
6. [Despliegue](#despliegue)

---

## Configuración Inicial

### Requisitos Previos
- Cuenta de Manus (ya configurada)
- Acceso a la plataforma Q10 para enlaces de cursos
- Dominio personalizado (opcional)
- Cuenta de Stripe (para pagos en producción)

### Variables de Entorno
El sistema inyecta automáticamente estas variables:
- `DATABASE_URL` - Conexión a la base de datos MySQL
- `JWT_SECRET` - Clave para firmar sesiones
- `VITE_APP_ID` - ID de aplicación Manus OAuth
- `OAUTH_SERVER_URL` - URL del servidor OAuth
- `VITE_OAUTH_PORTAL_URL` - Portal de login Manus

---

## Base de Datos

### Estructura de Tablas

#### `users`
- Almacena información de usuarios autenticados
- Campos: `id`, `openId`, `name`, `email`, `role` (admin/user), `createdAt`, `updatedAt`

#### `courses`
- Catálogo de cursos disponibles
- Campos: `id`, `title`, `description`, `price`, `instructor`, `level`, `q10Link`, `imageUrl`, `isActive`

#### `orders`
- Registro de compras de usuarios
- Campos: `id`, `userId`, `courseId`, `amount`, `status` (pending/completed/failed), `createdAt`, `updatedAt`

#### `transactions`
- Registro de transacciones de pago
- Campos: `id`, `orderId`, `stripeTransactionId`, `amount`, `status`, `metadata`

#### `emailLogs`
- Log de notificaciones enviadas
- Campos: `id`, `orderId`, `recipientEmail`, `emailType`, `status`, `sentAt`

### Migraciones
Las migraciones se aplican automáticamente. Para aplicarlas manualmente:

```bash
cd /home/ubuntu/q10-courses-platform
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

---

## Dominio Personalizado

### Opción 1: Subdominio Manus (Incluido)
Tu sitio está disponible en: `https://[tu-proyecto].manus.space`

### Opción 2: Dominio Personalizado
1. Compra un dominio en tu registrador preferido (GoDaddy, Namecheap, etc.)
2. Ve a **Configuración → Dominios** en el panel de Manus
3. Agrega tu dominio personalizado
4. Configura los registros DNS según las instrucciones de Manus
5. Espera a que se propague (24-48 horas)

### Configuración DNS
- **Tipo:** CNAME
- **Nombre:** @ (o tu subdominio)
- **Valor:** `[tu-proyecto].manus.space`

---

## Pagos con Stripe

### Configuración Demo (Actual)
El sistema incluye un procesador de pagos demo que:
- Simula transacciones sin necesidad de Stripe
- Usa tarjeta de prueba: `4242 4242 4242 4242`
- Confirma pagos automáticamente
- Envía notificaciones de prueba

### Migración a Stripe Real
Cuando estés listo para producción:

1. **Crear cuenta Stripe:**
   - Ve a [stripe.com](https://stripe.com)
   - Completa el proceso de verificación (KYC)

2. **Obtener claves API:**
   - Dashboard → Configuración → Claves de API
   - Copia tu **Secret Key** y **Publishable Key**

3. **Configurar en Manus:**
   - Ve a **Configuración → Pagos**
   - Ingresa tus claves de Stripe
   - El sistema se actualizará automáticamente

4. **Actualizar código:**
   - Reemplaza `/server/services/payment.ts` con integración real de Stripe
   - Implementa webhooks en `/api/stripe/webhook`

---

## Notificaciones por Email

### Configuración Actual
El sistema está configurado para enviar notificaciones automáticas:

#### Para Usuarios
- **Evento:** Compra completada
- **Contenido:** Confirmación de compra, acceso al curso, enlace a Q10
- **Envío:** Automático inmediatamente después del pago

#### Para Administrador
- **Evento:** Nueva compra realizada
- **Contenido:** Detalles del cliente, curso comprado, monto
- **Envío:** Automático inmediatamente después del pago

### Configurar Email Personalizado
1. Ve a **Configuración → Notificaciones**
2. Configura tu email de administrador
3. Personaliza plantillas de email (opcional)

### Plantillas de Email
Las plantillas se encuentran en:
- `/server/services/emailTemplates/` (crear si no existe)

Ejemplo de plantilla de confirmación:
```html
<h1>¡Gracias por tu compra!</h1>
<p>Has comprado exitosamente: {{courseName}}</p>
<p>Accede a tu curso: <a href="{{courseLink}}">{{courseLink}}</a></p>
```

---

## Despliegue

### Despliegue Automático
El sitio se despliega automáticamente cuando:
1. Haces cambios en el código
2. Ejecutas `webdev_save_checkpoint`
3. Haces clic en **Publicar** en el panel de Manus

### Verificar Despliegue
1. Ve a **Dashboard** en el panel de Manus
2. Verifica el estado del servidor
3. Revisa los logs en **Más → Logs**

### Monitoreo
- **Uptime:** Monitorizado automáticamente
- **Errores:** Registrados en los logs
- **Rendimiento:** Visible en el Dashboard

---

## Gestión de Cursos

### Panel de Administración
Accede a: `https://[tu-dominio]/admin`

**Funcionalidades:**
- ✅ Crear nuevos cursos
- ✅ Editar información de cursos
- ✅ Eliminar cursos
- ✅ Ver estadísticas de ventas
- ✅ Gestionar órdenes

### Agregar un Curso
1. Ve al **Panel de Administración**
2. Haz clic en **Nuevo Curso**
3. Completa la información:
   - Título
   - Descripción
   - Precio
   - Instructor
   - Nivel (Principiante/Intermedio/Avanzado)
   - Enlace Q10 (URL directa al curso en Q10)
4. Haz clic en **Guardar Curso**

### Enlace Q10
Cada curso debe tener un enlace directo a la plataforma Q10:
- Formato: `https://q10.com/course/[id-curso]`
- Los estudiantes accederán a través de este enlace después de comprar

---

## Troubleshooting

### El sitio no carga
1. Verifica que el servidor esté corriendo: **Dashboard → Estado**
2. Revisa los logs: **Más → Logs → devserver.log**
3. Reinicia el servidor: **Más → Reiniciar Servidor**

### Los pagos no se procesan
1. Verifica que el usuario esté autenticado
2. Revisa los logs: **Más → Logs → networkRequests.log**
3. Confirma que el courseId es válido

### Los emails no se envían
1. Verifica la configuración de email: **Configuración → Notificaciones**
2. Revisa los logs de email: **Más → Logs → devserver.log**
3. Confirma que el email del administrador está configurado

### Problemas de autenticación
1. Verifica que VITE_OAUTH_PORTAL_URL esté configurado
2. Revisa que el usuario esté registrado en Manus
3. Limpia cookies del navegador e intenta de nuevo

---

## Soporte y Recursos

- **Documentación Manus:** https://help.manus.im
- **Documentación Q10:** https://q10.com/docs
- **Documentación Stripe:** https://stripe.com/docs

---

## Checklist de Lanzamiento

- [ ] Base de datos configurada y migraciones aplicadas
- [ ] Cursos agregados al catálogo
- [ ] Dominio personalizado configurado (opcional)
- [ ] Email de administrador configurado
- [ ] Pagos de prueba funcionando
- [ ] Notificaciones por email funcionando
- [ ] Panel de administración probado
- [ ] Autenticación de usuarios funcionando
- [ ] Perfil de usuario mostrando compras
- [ ] Enlaces Q10 verificados

---

**Última actualización:** Mayo 2026
**Versión:** 1.0.0
