import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Loader2, Search, ArrowRight } from "lucide-react";

export default function Courses() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  // Placeholder data - will be replaced with tRPC query
  const mockCourses = [
    {
      id: 1,
      title: "Fundamentos de Marketing Digital",
      description: "Aprende las bases del marketing digital moderno",
      price: 49.99,
      instructor: "Juan Pérez",
      duration: "4 semanas",
      level: "beginner",
      imageUrl: "https://via.placeholder.com/400x300?text=Marketing",
      q10Link: "https://q10.com/course/marketing-digital",
    },
    {
      id: 2,
      title: "Diseño UX/UI Avanzado",
      description: "Domina el diseño de interfaces modernas",
      price: 79.99,
      instructor: "María García",
      duration: "6 semanas",
      level: "advanced",
      imageUrl: "https://via.placeholder.com/400x300?text=UX+Design",
      q10Link: "https://q10.com/course/ux-ui-design",
    },
    {
      id: 3,
      title: "Python para Ciencia de Datos",
      description: "Análisis de datos con Python y herramientas profesionales",
      price: 89.99,
      instructor: "Carlos López",
      duration: "8 semanas",
      level: "intermediate",
      imageUrl: "https://via.placeholder.com/400x300?text=Python",
      q10Link: "https://q10.com/course/python-data-science",
    },
    {
      id: 4,
      title: "Estrategia de Contenidos",
      description: "Crea estrategias de contenido que conviertan",
      price: 59.99,
      instructor: "Ana Rodríguez",
      duration: "5 semanas",
      level: "intermediate",
      imageUrl: "https://via.placeholder.com/400x300?text=Content",
      q10Link: "https://q10.com/course/content-strategy",
    },
  ];

  const filteredCourses = mockCourses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLevel = !selectedLevel || course.level === selectedLevel;
    return matchesSearch && matchesLevel;
  });

  const getLevelLabel = (level: string) => {
    const labels: Record<string, string> = {
      beginner: "Principiante",
      intermediate: "Intermedio",
      advanced: "Avanzado",
    };
    return labels[level] || level;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => navigate("/")}
            className="text-2xl font-bold tracking-tight hover:opacity-75 transition-opacity"
          >
            <span className="text-primary">Q10</span> Academy
          </button>
          <Button variant="ghost" onClick={() => navigate("/")}>
            Volver al Inicio
          </Button>
        </div>
      </nav>

      <main className="py-20">
        <div className="container">
          {/* Header */}
          <div className="mb-16">
            <h1 className="text-5xl md:text-6xl font-bold mb-4">
              Nuestros Cursos
            </h1>
            <div className="divider-line mb-4" />
            <p className="text-xl text-muted-foreground max-w-2xl">
              Explora nuestro catálogo de cursos diseñados por expertos para
              transformar tu carrera profesional.
            </p>
          </div>

          {/* Filters */}
          <div className="mb-12 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar cursos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="flex gap-2 flex-wrap">
              <Button
                variant={selectedLevel === null ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedLevel(null)}
              >
                Todos
              </Button>
              {["beginner", "intermediate", "advanced"].map((level) => (
                <Button
                  key={level}
                  variant={selectedLevel === level ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedLevel(level)}
                >
                  {getLevelLabel(level)}
                </Button>
              ))}
            </div>
          </div>

          {/* Courses Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map((course, index) => (
              <div
                key={course.id}
                className={`group bg-card border border-border rounded-sm overflow-hidden hover:shadow-lg hover:border-primary/30 transition-all duration-300 ${
                  isVisible
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-4"
                }`}
                style={{
                  transitionDelay: `${index * 100}ms`,
                }}
              >
                {/* Image */}
                <div className="relative h-48 bg-secondary overflow-hidden">
                  <img
                    src={course.imageUrl}
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4 bg-primary text-primary-foreground px-3 py-1 rounded-sm text-xs font-semibold">
                    {getLevelLabel(course.level)}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="text-xl font-bold mb-2 line-clamp-2">
                      {course.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {course.description}
                    </p>
                  </div>

                  {/* Meta */}
                  <div className="space-y-2 text-sm text-muted-foreground border-t border-border pt-4">
                    <div className="flex justify-between">
                      <span>Instructor:</span>
                      <span className="font-medium text-foreground">
                        {course.instructor}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Duración:</span>
                      <span className="font-medium text-foreground">
                        {course.duration}
                      </span>
                    </div>
                  </div>

                  {/* Price and CTA */}
                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div>
                      <span className="text-2xl font-bold text-primary">
                        ${course.price}
                      </span>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => navigate(`/courses/${course.id}`)}
                      className="group/btn"
                    >
                      Ver Detalles
                      <ArrowRight className="ml-2 w-3 h-3 group-hover/btn:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {filteredCourses.length === 0 && (
            <div className="text-center py-20">
              <p className="text-xl text-muted-foreground">
                No se encontraron cursos que coincidan con tu búsqueda.
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
