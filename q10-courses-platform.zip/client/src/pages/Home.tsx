import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { Star, BookOpen, Award, Users, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const testimonials = [
    {
      name: "María González",
      role: "Emprendedora Digital",
      text: "Los cursos transformaron completamente mi negocio. Contenido de calidad excepcional.",
      rating: 5,
    },
    {
      name: "Carlos Rodríguez",
      role: "Profesional de Marketing",
      text: "Excelente estructura pedagógica. Aprendí más en 4 semanas que en años anteriores.",
      rating: 5,
    },
    {
      name: "Ana Martínez",
      role: "Diseñadora Freelance",
      text: "Instructores expertos y contenido actualizado. Altamente recomendado.",
      rating: 5,
    },
  ];

  const benefits = [
    {
      icon: BookOpen,
      title: "Contenido Premium",
      description: "Cursos diseñados por expertos de la industria con enfoque práctico.",
    },
    {
      icon: Award,
      title: "Certificados Reconocidos",
      description: "Obtén certificados que validen tus nuevas habilidades.",
    },
    {
      icon: Users,
      title: "Comunidad Activa",
      description: "Conecta con otros estudiantes y profesionales de tu área.",
    },
    {
      icon: Star,
      title: "Acceso de por Vida",
      description: "Accede a los cursos cuando quieras, desde cualquier dispositivo.",
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="text-2xl font-bold tracking-tight">
            <span className="text-primary">Q10</span> Academy
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => navigate("/courses")}
              className="text-sm"
            >
              Cursos
            </Button>
            {isAuthenticated ? (
              <>
                <Button
                  variant="ghost"
                  onClick={() => navigate("/profile")}
                  className="text-sm"
                >
                  Mi Perfil
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate("/admin")}
                  className="text-sm"
                >
                  Admin
                </Button>
              </>
            ) : (
              <Button
                variant="default"
                onClick={() => (window.location.href = getLoginUrl())}
                className="text-sm"
              >
                Ingresar
              </Button>
            )}
          </div>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center overflow-hidden">
          {/* Background decoration */}
          <div className="absolute inset-0 -z-10">
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
          </div>

          <div className="container grid md:grid-cols-2 gap-12 items-center py-20">
            {/* Left: Hero Text */}
            <div
              className={`space-y-8 transition-all duration-1000 ${
                isVisible
                  ? "opacity-100 translate-x-0"
                  : "opacity-0 -translate-x-10"
              }`}
            >
              <div className="space-y-4">
                <h1 className="text-6xl md:text-7xl font-bold leading-tight">
                  Aprende de los
                  <span className="block text-primary">mejores</span>
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed max-w-lg">
                  Cursos en línea de calidad excepcional diseñados para transformar
                  tu carrera profesional. Acceso inmediato, contenido premium y
                  certificados reconocidos.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button
                  size="lg"
                  onClick={() => navigate("/courses")}
                  className="group"
                >
                  Explorar Cursos
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => navigate("/courses")}
                >
                  Ver Catálogo
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-8 pt-8 border-t border-border">
                <div>
                  <div className="text-3xl font-bold text-primary">50+</div>
                  <p className="text-sm text-muted-foreground">Cursos Disponibles</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">10K+</div>
                  <p className="text-sm text-muted-foreground">Estudiantes Activos</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">95%</div>
                  <p className="text-sm text-muted-foreground">Satisfacción</p>
                </div>
              </div>
            </div>

            {/* Right: Visual Element */}
            <div
              className={`relative h-96 md:h-full transition-all duration-1000 delay-300 ${
                isVisible
                  ? "opacity-100 translate-x-0"
                  : "opacity-0 translate-x-10"
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg border border-primary/20" />
              <div className="absolute inset-4 bg-gradient-to-tr from-primary/5 to-transparent rounded-lg" />
              <div className="relative h-full flex items-center justify-center">
                <div className="text-center">
                  <BookOpen className="w-24 h-24 text-primary/30 mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    Plataforma de Educación Premium
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 border-t border-border">
          <div className="container">
            <div className="max-w-2xl mb-16">
              <h2 className="text-5xl font-bold mb-4">¿Por qué elegirnos?</h2>
              <div className="divider-line" />
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {benefits.map((benefit, index) => {
                const Icon = benefit.icon;
                return (
                  <div
                    key={index}
                    className={`p-8 bg-card rounded-sm border border-border transition-all duration-500 hover:shadow-lg hover:border-primary/30 ${
                      isVisible
                        ? "opacity-100 translate-y-0"
                        : "opacity-0 translate-y-4"
                    }`}
                    style={{
                      transitionDelay: `${400 + index * 100}ms`,
                    }}
                  >
                    <Icon className="w-8 h-8 text-primary mb-4" />
                    <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-20 bg-secondary/30">
          <div className="container">
            <div className="max-w-2xl mb-16">
              <h2 className="text-5xl font-bold mb-4">Lo que dicen nuestros estudiantes</h2>
              <div className="divider-line" />
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className={`p-8 bg-card rounded-sm border border-border transition-all duration-500 ${
                    isVisible
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 translate-y-4"
                  }`}
                  style={{
                    transitionDelay: `${600 + index * 100}ms`,
                  }}
                >
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-4 h-4 fill-primary text-primary"
                      />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    "{testimonial.text}"
                  </p>
                  <div>
                    <p className="font-bold text-sm">{testimonial.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {testimonial.role}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 border-t border-border">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center space-y-8">
              <h2 className="text-5xl font-bold">
                Comienza tu transformación hoy
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Acceso inmediato a todos nuestros cursos. Aprende a tu propio ritmo
                y obtén certificados reconocidos en la industria.
              </p>
              <Button
                size="lg"
                onClick={() => navigate("/courses")}
                className="group mx-auto"
              >
                Explorar Cursos Ahora
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-secondary/20 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Q10 Academy</h4>
              <p className="text-sm text-muted-foreground">
                Educación de calidad para profesionales.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Plataforma</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <button
                    onClick={() => navigate("/courses")}
                    className="hover:text-foreground transition-colors"
                  >
                    Cursos
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate("/profile")}
                    className="hover:text-foreground transition-colors"
                  >
                    Mi Perfil
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Términos de Servicio
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Privacidad
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contacto</h4>
              <p className="text-sm text-muted-foreground">
                info@q10academy.com
              </p>
            </div>
          </div>

          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Q10 Academy. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
