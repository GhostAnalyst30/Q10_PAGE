import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight } from "lucide-react";

export default function PaymentConfirmation() {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Auto-redirect after 5 seconds
    const timer = setTimeout(() => {
      navigate("/profile");
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => navigate("/")}
            className="text-2xl font-bold tracking-tight hover:opacity-75 transition-opacity"
          >
            <span className="text-primary">Q10</span> Academy
          </button>
        </div>
      </nav>

      <main className="flex-1 flex items-center justify-center py-12">
        <div className="container max-w-md">
          <div className="bg-card border border-border rounded-sm p-8 space-y-6 text-center">
            {/* Success Icon */}
            <div className="flex justify-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center animate-pulse">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
            </div>

            {/* Success Message */}
            <div className="space-y-2">
              <h1 className="text-3xl font-bold">¡Pago Confirmado!</h1>
              <p className="text-muted-foreground">
                Tu compra ha sido procesada exitosamente. Recibirás un email de confirmación en breve.
              </p>
            </div>

            {/* Details */}
            <div className="bg-secondary/30 rounded-sm p-4 text-left space-y-3">
              <div>
                <p className="text-xs text-muted-foreground mb-1">
                  ESTADO DEL PAGO
                </p>
                <p className="font-semibold text-green-600">Confirmado</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">
                  PRÓXIMO PASO
                </p>
                <p className="font-semibold">
                  Accede a tu perfil para ver tus cursos
                </p>
              </div>
            </div>

            {/* CTA */}
            <div className="space-y-3 pt-4">
              <p className="text-sm text-muted-foreground">
                Redirigiendo en 5 segundos...
              </p>
              <Button
                onClick={() => navigate("/profile")}
                className="w-full gap-2"
              >
                Ir a Mi Perfil
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
