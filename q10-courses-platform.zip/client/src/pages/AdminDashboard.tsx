import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import {
  Plus,
  Edit2,
  Trash2,
  DollarSign,
  Users,
  BookOpen,
  TrendingUp,
} from "lucide-react";

interface Course {
  id: number;
  title: string;
  price: number;
  instructor: string;
  level: string;
  isActive: boolean;
}

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [courses, setCourses] = useState<Course[]>([
    {
      id: 1,
      title: "Fundamentos de Marketing Digital",
      price: 49.99,
      instructor: "Juan Pérez",
      level: "beginner",
      isActive: true,
    },
    {
      id: 2,
      title: "Diseño UX/UI Avanzado",
      price: 79.99,
      instructor: "María García",
      level: "advanced",
      isActive: true,
    },
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [newCourse, setNewCourse] = useState({
    title: "",
    price: "",
    instructor: "",
    level: "beginner",
  });

  useEffect(() => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/admin");
    }
    // Check if user is admin
    if (user?.role !== "admin") {
      navigate("/");
    }
  }, [isAuthenticated, user?.role, navigate]);

  const handleAddCourse = (e: React.FormEvent) => {
    e.preventDefault();
    const newCourseData: Course = {
      id: Math.max(...courses.map((c) => c.id), 0) + 1,
      title: newCourse.title,
      price: parseFloat(newCourse.price),
      instructor: newCourse.instructor,
      level: newCourse.level,
      isActive: true,
    };
    setCourses([...courses, newCourseData]);
    setNewCourse({ title: "", price: "", instructor: "", level: "beginner" });
    setShowAddForm(false);
  };

  const handleDeleteCourse = (id: number) => {
    setCourses(courses.filter((c) => c.id !== id));
  };

  const totalRevenue = courses.reduce((sum, course) => sum + course.price, 0);

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">
            Acceso denegado. Solo administradores pueden acceder.
          </p>
          <Button onClick={() => navigate("/")}>Volver al Inicio</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => navigate("/")}
            className="text-2xl font-bold tracking-tight hover:opacity-75 transition-opacity"
          >
            <span className="text-primary">Q10</span> Academy
          </button>
          <div className="text-sm text-muted-foreground">
            Admin Panel - {user?.name}
          </div>
        </div>
      </nav>

      <main className="py-12">
        <div className="container">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-4xl font-bold mb-4">Panel de Administración</h1>
            <div className="divider-line" />
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            <div className="bg-card border border-border rounded-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Cursos Activos
                  </p>
                  <p className="text-3xl font-bold">
                    {courses.filter((c) => c.isActive).length}
                  </p>
                </div>
                <BookOpen className="w-8 h-8 text-primary opacity-50" />
              </div>
            </div>

            <div className="bg-card border border-border rounded-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Precio Promedio
                  </p>
                  <p className="text-3xl font-bold">
                    ${(totalRevenue / courses.length).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-primary opacity-50" />
              </div>
            </div>

            <div className="bg-card border border-border rounded-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Ingresos Potenciales
                  </p>
                  <p className="text-3xl font-bold">${totalRevenue.toFixed(2)}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-primary opacity-50" />
              </div>
            </div>

            <div className="bg-card border border-border rounded-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Estudiantes
                  </p>
                  <p className="text-3xl font-bold">2</p>
                </div>
                <Users className="w-8 h-8 text-primary opacity-50" />
              </div>
            </div>
          </div>

          {/* Courses Section */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Gestionar Cursos</h2>
              <Button
                onClick={() => setShowAddForm(!showAddForm)}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                Nuevo Curso
              </Button>
            </div>

            {/* Add Course Form */}
            {showAddForm && (
              <div className="bg-card border border-border rounded-sm p-6 mb-6 space-y-4">
                <h3 className="font-bold text-lg">Agregar Nuevo Curso</h3>
                <form onSubmit={handleAddCourse} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <Input
                      placeholder="Título del curso"
                      value={newCourse.title}
                      onChange={(e) =>
                        setNewCourse({ ...newCourse, title: e.target.value })
                      }
                      required
                    />
                    <Input
                      placeholder="Precio"
                      type="number"
                      step="0.01"
                      value={newCourse.price}
                      onChange={(e) =>
                        setNewCourse({ ...newCourse, price: e.target.value })
                      }
                      required
                    />
                    <Input
                      placeholder="Instructor"
                      value={newCourse.instructor}
                      onChange={(e) =>
                        setNewCourse({
                          ...newCourse,
                          instructor: e.target.value,
                        })
                      }
                      required
                    />
                    <select
                      value={newCourse.level}
                      onChange={(e) =>
                        setNewCourse({ ...newCourse, level: e.target.value })
                      }
                      className="px-3 py-2 border border-border rounded-sm bg-background"
                    >
                      <option value="beginner">Principiante</option>
                      <option value="intermediate">Intermedio</option>
                      <option value="advanced">Avanzado</option>
                    </select>
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit">Guardar Curso</Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowAddForm(false)}
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </div>
            )}

            {/* Courses Table */}
            <div className="bg-card border border-border rounded-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-secondary/30 border-b border-border">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Título
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Instructor
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Nivel
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Precio
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Estado
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold">
                        Acciones
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {courses.map((course) => (
                      <tr key={course.id} className="hover:bg-secondary/20">
                        <td className="px-6 py-4 text-sm font-medium">
                          {course.title}
                        </td>
                        <td className="px-6 py-4 text-sm text-muted-foreground">
                          {course.instructor}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <span className="px-2 py-1 bg-primary/10 text-primary rounded-sm text-xs font-semibold">
                            {course.level}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm font-semibold">
                          ${course.price}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-2 h-2 rounded-full ${
                                course.isActive
                                  ? "bg-green-500"
                                  : "bg-red-500"
                              }`}
                            />
                            {course.isActive ? "Activo" : "Inactivo"}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="gap-1"
                              onClick={() =>
                                alert("Editar curso: " + course.title)
                              }
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="gap-1 text-destructive hover:text-destructive"
                              onClick={() => handleDeleteCourse(course.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Recent Orders */}
          <div>
            <h2 className="text-2xl font-bold mb-6">Órdenes Recientes</h2>
            <div className="bg-card border border-border rounded-sm p-6 text-center text-muted-foreground">
              <p>No hay órdenes registradas aún.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
