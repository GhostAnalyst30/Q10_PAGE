import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import * as db from "../db";
import { TRPCError } from "@trpc/server";

export const ordersRouter = router({
  // Get user's orders (protected)
  list: protectedProcedure.query(async ({ ctx }) => {
    return await db.getUserOrders(ctx.user.id);
  }),

  // Get order by ID (protected)
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const order = await db.getOrderById(input.id);
      if (!order || order.userId !== ctx.user.id) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "You don't have access to this order",
        });
      }
      return order;
    }),

  // Create order (protected)
  create: protectedProcedure
    .input(
      z.object({
        courseId: z.number(),
        amount: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Verify course exists
      const course = await db.getCourseById(input.courseId);
      if (!course) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Course not found",
        });
      }

      // Check if user already purchased this course
      const existingOrders = await db.getUserOrders(ctx.user.id);
      const alreadyPurchased = existingOrders.some(
        (o) => o.courseId === input.courseId && o.status === "completed"
      );
      if (alreadyPurchased) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "You have already purchased this course",
        });
      }

      // Create order
      const result = await db.createOrder({
        userId: ctx.user.id,
        courseId: input.courseId,
        amount: input.amount,
        status: "pending",
      });

      return result;
    }),

  // Update order status (protected - only own orders)
  updateStatus: protectedProcedure
    .input(
      z.object({
        orderId: z.number(),
        status: z.enum(["pending", "completed", "failed", "refunded"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const order = await db.getOrderById(input.orderId);
      if (!order || order.userId !== ctx.user.id) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "You don't have access to this order",
        });
      }

      return await db.updateOrderStatus(input.orderId, input.status);
    }),

  // Webhook for Stripe payment confirmation (public but secured with signature)
  confirmPayment: publicProcedure
    .input(
      z.object({
        orderId: z.number(),
        stripePaymentId: z.string(),
        status: z.enum(["succeeded", "failed"]),
      })
    )
    .mutation(async ({ input }) => {
      const order = await db.getOrderById(input.orderId);
      if (!order) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Order not found",
        });
      }

      // Update order with Stripe payment ID
      await db.updateOrderStatus(
        input.orderId,
        input.status === "succeeded" ? "completed" : "failed"
      );

      // Create transaction record
      if (input.status === "succeeded") {
        await db.createTransaction({
          orderId: input.orderId,
          stripeTransactionId: input.stripePaymentId,
          amount: order.amount,
          status: "succeeded",
        });

        // Log email notification
        const user = await db.getUserByOpenId(""); // This should be improved
        if (user?.email) {
          await db.createEmailLog({
            orderId: input.orderId,
            recipientEmail: user.email,
            recipientType: "user",
            emailType: "purchase_confirmation",
            status: "pending",
          });
        }
      }

      return { success: true };
    }),
});
