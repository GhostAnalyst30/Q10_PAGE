import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { BookOpen, Download, LogOut, ArrowRight } from "lucide-react";

export default function UserProfile() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/profile");
    }
  }, [isAuthenticated]);

  // Placeholder purchases data
  const purchases = [
    {
      id: 1,
      courseTitle: "Fundamentos de Marketing Digital",
      purchaseDate: "2026-05-20",
      price: 49.99,
      status: "completed",
      accessUrl: "https://q10.com/course/marketing-digital",
    },
    {
      id: 2,
      courseTitle: "Diseño UX/UI Avanzado",
      purchaseDate: "2026-05-15",
      price: 79.99,
      status: "completed",
      accessUrl: "https://q10.com/course/ux-ui-design",
    },
  ];

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">
            Redirigiendo a autenticación...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => navigate("/")}
            className="text-2xl font-bold tracking-tight hover:opacity-75 transition-opacity"
          >
            <span className="text-primary">Q10</span> Academy
          </button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => navigate("/courses")}>
              Explorar Cursos
            </Button>
            <Button variant="outline" onClick={handleLogout} className="gap-2">
              <LogOut className="w-4 h-4" />
              Salir
            </Button>
          </div>
        </div>
      </nav>

      <main className="py-12">
        <div className="container max-w-4xl">
          {/* Profile Header */}
          <div
            className={`mb-12 transition-all duration-500 ${
              isVisible
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-4"
            }`}
          >
            <div className="bg-card border border-border rounded-sm p-8 space-y-4">
              <div>
                <h1 className="text-4xl font-bold mb-2">Mi Perfil</h1>
                <p className="text-muted-foreground">
                  Bienvenido, {user?.name || "Estudiante"}
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-6 pt-6 border-t border-border">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Email</p>
                  <p className="font-semibold">{user?.email || "No disponible"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Miembro desde
                  </p>
                  <p className="font-semibold">
                    {user?.createdAt
                      ? new Date(user.createdAt).toLocaleDateString("es-ES")
                      : "Recientemente"}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">
                    Cursos Comprados
                  </p>
                  <p className="font-semibold">{purchases.length}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Purchases Section */}
          <div
            className={`transition-all duration-500 delay-300 ${
              isVisible
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-4"
            }`}
          >
            <div className="mb-8">
              <h2 className="text-3xl font-bold mb-4">Mis Cursos</h2>
              <div className="divider-line" />
            </div>

            {purchases.length > 0 ? (
              <div className="space-y-4">
                {purchases.map((purchase) => (
                  <div
                    key={purchase.id}
                    className="bg-card border border-border rounded-sm p-6 hover:border-primary/30 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <BookOpen className="w-5 h-5 text-primary" />
                          <h3 className="text-xl font-bold">
                            {purchase.courseTitle}
                          </h3>
                        </div>
                        <div className="grid md:grid-cols-3 gap-4 text-sm text-muted-foreground mt-4">
                          <div>
                            <p className="text-xs mb-1">Fecha de Compra</p>
                            <p className="font-semibold text-foreground">
                              {new Date(
                                purchase.purchaseDate
                              ).toLocaleDateString("es-ES")}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs mb-1">Precio Pagado</p>
                            <p className="font-semibold text-foreground">
                              ${purchase.price}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs mb-1">Estado</p>
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-green-500 rounded-full" />
                              <p className="font-semibold text-foreground">
                                Activo
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2">
                        <Button
                          onClick={() =>
                            window.open(purchase.accessUrl, "_blank")
                          }
                          className="gap-2 whitespace-nowrap"
                        >
                          Acceder al Curso
                          <ArrowRight className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="gap-2">
                          <Download className="w-4 h-4" />
                          Certificado
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-secondary/30 border border-border rounded-sm p-12 text-center space-y-4">
                <BookOpen className="w-12 h-12 text-muted-foreground mx-auto opacity-50" />
                <p className="text-muted-foreground">
                  Aún no has comprado ningún curso
                </p>
                <Button onClick={() => navigate("/courses")}>
                  Explorar Cursos
                </Button>
              </div>
            )}
          </div>

          {/* Account Settings */}
          <div
            className={`mt-12 transition-all duration-500 delay-500 ${
              isVisible
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-4"
            }`}
          >
            <div className="bg-card border border-border rounded-sm p-6 space-y-4">
              <h3 className="text-xl font-bold">Configuración de Cuenta</h3>
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  Cambiar Contraseña
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  Notificaciones
                </Button>
                <Button
                  variant="destructive"
                  className="w-full justify-start"
                  onClick={handleLogout}
                >
                  Cerrar Sesión
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
