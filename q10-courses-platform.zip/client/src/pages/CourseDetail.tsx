import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, CheckCircle2, Clock, User, BookOpen } from "lucide-react";

export default function CourseDetail() {
  const [, navigate] = useLocation();
  const [route, params] = useRoute("/courses/:id");
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  // Placeholder course data - will be replaced with tRPC query
  const course = {
    id: parseInt(params?.id || "1"),
    title: "Fundamentos de Marketing Digital",
    description: "Aprende las bases del marketing digital moderno",
    longDescription:
      "Este curso completo te enseñará todo lo que necesitas saber sobre marketing digital. Desde estrategia hasta ejecución, cubriremos todos los aspectos del marketing en línea.",
    price: 49.99,
    instructor: "Juan Pérez",
    instructorBio:
      "Experto en marketing digital con más de 10 años de experiencia en la industria.",
    duration: "4 semanas",
    level: "Principiante",
    imageUrl: "https://via.placeholder.com/800x400?text=Marketing",
    q10Link: "https://q10.com/course/marketing-digital",
    curriculum: [
      {
        module: "Módulo 1",
        title: "Introducción al Marketing Digital",
        lessons: [
          "¿Qué es el marketing digital?",
          "Canales digitales principales",
          "Tendencias actuales",
        ],
      },
      {
        module: "Módulo 2",
        title: "SEO y SEM",
        lessons: [
          "Fundamentos de SEO",
          "Palabras clave y posicionamiento",
          "Google Ads básico",
        ],
      },
      {
        module: "Módulo 3",
        title: "Social Media Marketing",
        lessons: [
          "Estrategia en redes sociales",
          "Contenido viral",
          "Publicidad en redes",
        ],
      },
      {
        module: "Módulo 4",
        title: "Email Marketing y Conversión",
        lessons: [
          "Construcción de listas",
          "Automatización",
          "Optimización de conversiones",
        ],
      },
    ],
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => navigate("/")}
            className="text-2xl font-bold tracking-tight hover:opacity-75 transition-opacity"
          >
            <span className="text-primary">Q10</span> Academy
          </button>
          <Button
            variant="ghost"
            onClick={() => navigate("/courses")}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Volver a Cursos
          </Button>
        </div>
      </nav>

      <main className="py-12">
        <div className="container">
          {/* Hero Section */}
          <div
            className={`mb-12 transition-all duration-500 ${
              isVisible
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-4"
            }`}
          >
            <div className="grid md:grid-cols-3 gap-8 items-start">
              {/* Left: Content */}
              <div className="md:col-span-2 space-y-6">
                <div>
                  <h1 className="text-5xl font-bold mb-4">{course.title}</h1>
                  <p className="text-xl text-muted-foreground">
                    {course.longDescription}
                  </p>
                </div>

                {/* Course Info */}
                <div className="grid grid-cols-2 gap-4 py-6 border-y border-border">
                  <div className="flex gap-3">
                    <User className="w-5 h-5 text-primary flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground">Instructor</p>
                      <p className="font-semibold">{course.instructor}</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <Clock className="w-5 h-5 text-primary flex-shrink-0" />
                    <div>
                      <p className="text-sm text-muted-foreground">Duración</p>
                      <p className="font-semibold">{course.duration}</p>
                    </div>
                  </div>
                </div>

                {/* Instructor Bio */}
                <div className="bg-secondary/30 p-6 rounded-sm border border-border">
                  <h3 className="font-bold mb-2">Sobre el Instructor</h3>
                  <p className="text-muted-foreground">{course.instructorBio}</p>
                </div>
              </div>

              {/* Right: Sidebar */}
              <div className="sticky top-20 space-y-6">
                {/* Price Card */}
                <div className="bg-card border border-border rounded-sm p-6 space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Precio</p>
                    <p className="text-4xl font-bold text-primary">
                      ${course.price}
                    </p>
                  </div>

                  <Button
                    size="lg"
                    className="w-full"
                    onClick={() => navigate(`/checkout/${course.id}`)}
                  >
                    Comprar Ahora
                  </Button>

                  <Button
                    size="lg"
                    variant="outline"
                    className="w-full"
                    onClick={() => window.open(course.q10Link, "_blank")}
                  >
                    Ver en Q10
                  </Button>

                  <div className="space-y-2 text-sm">
                    <div className="flex gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                      <span>Acceso de por vida</span>
                    </div>
                    <div className="flex gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                      <span>Certificado incluido</span>
                    </div>
                    <div className="flex gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                      <span>Soporte 24/7</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Curriculum Section */}
          <div
            className={`transition-all duration-500 delay-300 ${
              isVisible
                ? "opacity-100 translate-y-0"
                : "opacity-0 translate-y-4"
            }`}
          >
            <div className="mb-8">
              <h2 className="text-4xl font-bold mb-4">Temario del Curso</h2>
              <div className="divider-line" />
            </div>

            <div className="space-y-4">
              {course.curriculum.map((module, index) => (
                <div
                  key={index}
                  className="bg-card border border-border rounded-sm p-6 hover:border-primary/30 transition-colors"
                >
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <BookOpen className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-sm font-semibold text-primary">
                            {module.module}
                          </p>
                          <h3 className="text-lg font-bold">{module.title}</h3>
                        </div>
                      </div>
                      <ul className="space-y-2">
                        {module.lessons.map((lesson, lessonIndex) => (
                          <li
                            key={lessonIndex}
                            className="flex gap-2 text-muted-foreground"
                          >
                            <span className="text-primary">•</span>
                            <span>{lesson}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-16 py-12 bg-primary/5 rounded-sm border border-primary/20 text-center space-y-4">
            <h3 className="text-3xl font-bold">¿Listo para comenzar?</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Acceso inmediato al curso y todos sus materiales. Aprende a tu
              propio ritmo.
            </p>
            <Button
              size="lg"
              onClick={() => navigate(`/checkout/${course.id}`)}
            >
              Comprar Ahora - ${course.price}
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
