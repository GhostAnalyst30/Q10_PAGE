
  # Curso de venta online

  This is a code bundle for Curso de venta online. The original project is available at https://www.figma.com/design/1N59jrDKT8fIdPL6GuNRnl/Curso-de-venta-online.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  