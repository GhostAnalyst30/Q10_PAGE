import { z } from "zod";
import { publicProcedure, protectedProcedure, router, adminProcedure } from "../_core/trpc";
import * as db from "../db";

export const coursesRouter = router({
  // Get all active courses (public)
  list: publicProcedure.query(async () => {
    return await db.getAllCourses();
  }),

  // Get course by ID (public)
  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await db.getCourseById(input.id);
    }),

  // Create course (admin only)
  create: adminProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        longDescription: z.string().optional(),
        price: z.string().min(1), // Decimal as string
        instructor: z.string().optional(),
        instructorBio: z.string().optional(),
        duration: z.string().optional(),
        level: z.enum(["beginner", "intermediate", "advanced"]).optional(),
        imageUrl: z.string().optional(),
        q10Link: z.string().url(),
        curriculum: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createCourse({
        ...input,
        level: input.level || "beginner",
        isActive: true,
      });
    }),

  // Update course (admin only)
  update: adminProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        longDescription: z.string().optional(),
        price: z.string().optional(), // Decimal as string
        instructor: z.string().optional(),
        instructorBio: z.string().optional(),
        duration: z.string().optional(),
        level: z.enum(["beginner", "intermediate", "advanced"]).optional(),
        imageUrl: z.string().optional(),
        q10Link: z.string().url().optional(),
        curriculum: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await db.updateCourse(id, data);
    }),

  // Delete course (admin only)
  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      return await db.deleteCourse(input.id);
    }),
});
